import db
from flask import Flask

app = Flask(__name__)

@app.route("/")
def home():
    return "Hello, World!"

#test to insert data to the data base
@app.route("/test")
def test():
    db.db.collection.insert_one({"name": "John"})
    return "Connected to the data base!"

@app.route("/register_user")
def register_user(myjson):
    with open(myjson, 'r') as data_file:
        data_json = json.load(data_file)
    db.user_collection.insert_many(data_json)
    db.user_collection.update_many({},{"$set": {'dataid': []}})
    return "users are registered!"

@app.route("/register_data")
def register_data(myjson):
    with open(myjson, 'r') as data_file:
      db.data_json = json.load(data_file)
    db.data_collection.insert_many(data_json)
    for x in db.data_collection.find():
       db.user_collection.update_one({"_id": x["userid"]}, {"$push": {"dataid": x["_id"]}})
    return "data are saved!"

@app.route("/find_user")
def find_user(key,value):
    myquery = {key: value}
    return flask.jsonify(db.user_collection.find(myquery))

@app.route("/find_data")
def find_data(dataid):
    myquery = {"_id" : dataid}
    return flask.jsonify(db.data_collection.find(myquery))


if __name__ == "__main__":
    app.run(debug=True)
