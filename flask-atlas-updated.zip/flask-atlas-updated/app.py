import db
import json
from flask import Flask
from flask import jsonify
from bson import ObjectId

class JSONEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, ObjectId):
            return str(o)
        return json.JSONEncoder.default(self, o)
#from mongoengine_jsonencoder import MongoEngineJSONEncoder
app = Flask(__name__)


@app.route("/")
def home():
    return "Hello, World!"

#test to insert data to the data base
@app.route("/test")
def test():
    db.db.collection.insert_one({"name": "John"})
    return "Connected to the data base!"

@app.route("/register_user")
def register_user():
    with open('info.json', 'r') as data_file:
        try:
            data_json = json.load(data_file)
        except ValueError:
            print("invalid json; please try again")
        else:
            pass
    db.user_collection.insert_many(data_json)
    db.user_collection.update_many({},{"$set": {'dataid': []}})
    return "users are registered!"

@app.route("/register_data")
#myjson should be removed
#and provided just like 'info.json' in the last function
def register_data():
    with open('data.json', 'r') as data_file:
        try:
            data_json = json.load(data_file)
        except ValueError:
            print("invalid json; please try again")
        else:
            pass
    db.data_collection.insert_many(data_json)
    for x in db.data_collection.find():

        db.user_collection.update_one({"_id": ObjectId(x["userid"])}, {"$push": {"dataid": x["_id"]}})
    return "data are saved!"

@app.route("/find_user/<key>/<value>")
def find_user(key,value):
    
    documents = [doc for doc in db.user_collection.find({}, {key:value})]
    return JSONEncoder().encode({'result':documents})

@app.route("/find_data/<dataid>")
def find_data(dataid):
    myquery = {"_id" : dataid}
    documents = [doc for doc in db.data_collection.find({}, myquery)]
    return JSONEncoder().encode({'result':documents})


if __name__ == "__main__":
    app.run(debug=True)
