from kafka import KafkaConsumer

consumer = KafkaConsumer('msg_collection')

for msg in consumer:
    msg_json = json.loads(msg.value)
#    print(msg_collection.insert_one(msg_json).inserted_id)
    print(msg_json)
