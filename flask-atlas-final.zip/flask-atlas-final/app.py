import db
import json
from flask import Flask
from flask import jsonify
from bson import ObjectId
from time import sleep
from kafka import KafkaProducer
producer = KafkaProducer(bootstrap_servers='localhost:9092')


class JSONEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, ObjectId):
            return str(o)
        return json.JSONEncoder.default(self, o)
#from mongoengine_jsonencoder import MongoEngineJSONEncoder
app = Flask(__name__)

@app.route("/")
def home():
    return "Hello, World!"

#test to insert data to the data base
@app.route("/test")
def test():
    db.db.collection.insert_one({"name": "John"})
    return "Connected to the data base!"

@app.route("/register_user")
def register_user():
    with open('info.json', 'r') as data_file:
        try:
            data_json = json.load(data_file)
        except ValueError:
            print("invalid json; please try again")
        else:
            pass
    db.user_collection.insert_many(data_json)
   
    db.user_collection.update_many({},{"$set": {'dataid': []}})
    for x in db.user_collection.find():
        message = "user_collection is getting updated; {} with id {} is getting appended to user".format(x["name"], x["_id"])
        message_dict = {}
        message_dict['meta_string'] = message
        producer.send('msg_collection', json.dumps(message_dict).encode('utf-8'))
        sleep(1)
    return "users are registered!"

@app.route("/register_data")
#myjson should be removed
#and provided just like 'info.json' in the last function
def register_data():
    with open('data.json', 'r') as data_file:
        try:
            data_json = json.load(data_file)
        except ValueError:
            print("invalid json; please try again")
        else:
            pass
    db.data_collection.insert_many(data_json)

    counter = 1
    for x in db.data_collection.find():

        db.user_collection.update_one({"_id": ObjectId(x["userid"])}, {"$push": {"dataid": str(counter)}})
        
        db.data_collection.update_one({"_id": x["_id"]}, {"$set": {'dataid': str(counter)}})
        counter += 1
        message = "user_collection is getting updated; a new data with id {} is getting appended to user with id {}".format(x["_id"], x["userid"])
        message_dict = {}
        message_dict['meta_string'] = message
        producer.send('msg_collection', json.dumps(message_dict).encode('utf-8'))
        sleep(1)
    return "data are saved!"

@app.route("/find_user/<key>/<value>")
def find_user(key,value):
    
    documents = [doc for doc in db.user_collection.find({key:value})]
    return JSONEncoder().encode({'result':documents})

@app.route("/find_data/<key>/<value>")
def find_data(key, value):
    
    documents = [doc for doc in db.data_collection.find({key: value})]
    return JSONEncoder().encode({'result':documents})


if __name__ == "__main__":
    app.run(debug=True)
